'use strict';
// Low-poly architecture in metres. All opaque geometry shares one vertex buffer.
function loungeGeometry(){
 const data=[];let seed=81;
 function random(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296}
 function quad(a,b,c,d,col,light){for(const v of [a,b,c,a,c,d])data.push(...v,...col.map(n=>n*light))}
 function box(x,y,z,w,h,d,col){
  const a=[x-w/2,y,z-d/2],b=[x+w/2,y,z-d/2],c=[x+w/2,y,z+d/2],e=[x-w/2,y,z+d/2];
  const top=p=>[p[0],p[1]+h,p[2]],A=top(a),B=top(b),C=top(c),E=top(e);
  quad(A,B,C,E,col,1.06);quad(a,e,c,b,col,.57);quad(a,b,B,A,col,.77);quad(b,c,C,B,col,.65);quad(c,e,E,C,col,.91);quad(e,a,A,E,col,.82)
 }
 const oak=[.65,.46,.31],cream=[.89,.85,.76],stone=[.69,.72,.73],green=[.15,.33,.26];
 box(0,-.26,0,18,.24,15,stone);
 for(let k=0;k<51;k++){const shade=.94+random()*.1;box(-8.8+k*.35,-.025,0,.346,.025,15,oak.map(n=>n*shade))}
 // Shade canopy, open front, recessed roof lights and timber slats.
 box(0,3.65,1.8,18,.3,11.4,cream);
 for(let i=0;i<28;i++)box(-8.55+i*.64,3.55,1.8,.09,.1,11.4,oak);
 for(const x of [-8,8])for(const z of [-4,5.8])box(x,0,z,.26,3.7,.26,cream);
 for(const x of [-6,0,6])box(x,3.53,-.65,.06,.025,5.4,[1,.92,.71]);
 for(const x of [-8.4,8.4])box(x,.8,-.5,.07,.08,13.2,stone);
 for(const x of [-8,-4,0,4,8])box(x,0,-7.1,.07,.88,.07,stone);
 box(0,.86,-7.1,17.1,.06,.08,cream);
 function sofa(x,z){box(x,.14,z,2.8,.25,1,oak);box(x,.39,z,2.75,.23,.96,cream);box(x,.55,z+.44,2.8,.59,.18,cream);for(const sign of [-1,1])box(x+sign*1.34,.32,z,.18,.46,1.04,cream)}
 sofa(-2.8,-4.7);sofa(2.1,4);box(-2.65,.05,-5.85,.9,.34,.44,stone);box(-2.65,.39,-5.85,1.75,.09,.83,cream);
 box(0,0,6.9,16,3.65,.18,cream);for(let i=0;i<38;i++)box(-7+i*.39,.05,6.74,.11,3.43,.1,oak);
 function planter(x,z){box(x,0,z,.67,.63,.67,stone);box(x,.58,z,.09,.74,.09,oak);for(let i=0;i<24;i++){let a=random()*6.28,r=.22+random()*.42,y=.82+random()*.48,tip=[x+Math.sin(a)*r,y+.16+random()*.46,z+Math.cos(a)*r],p=[x,y,z],s=.09;quad(p,[x+s*Math.cos(a),y+.19,z-s*Math.sin(a)],tip,[x-s*Math.cos(a),y+.16,z+s*Math.sin(a)],green,.72+random()*.72)}}
 for(const pair of [[-5,-4],[2.8,-5.2],[-6,3],[6,4.3]])planter(...pair);
 return new Float32Array(data)
}
const roomMesh=loungeGeometry();
function createLounge(canvas,onReady){
 const gl=canvas.getContext('webgl',{alpha:true,antialias:false,depth:true,preserveDrawingBuffer:false,powerPreference:'low-power'});if(!gl)return null;
 let disposed=false;
 function program(v,f){const p=gl.createProgram();for(const [type,src] of [[gl.VERTEX_SHADER,v],[gl.FRAGMENT_SHADER,f]]){const sh=gl.createShader(type);gl.shaderSource(sh,src);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));gl.attachShader(p,sh);gl.deleteShader(sh)}gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
 const sky=program('attribute vec2 pos;varying vec2 uv;void main(){uv=pos;gl_Position=vec4(pos,0.,1.);}', 'precision mediump float;varying vec2 uv;uniform vec4 rot;uniform vec2 lens;uniform sampler2D photo;void main(){vec3 d=normalize(vec3(uv*lens,1.));float y=d.y*rot.w+d.z*rot.z;float z=d.z*rot.w-d.y*rot.z;float x=d.x*rot.y+z*rot.x;z=z*rot.y-d.x*rot.x;float u=1.-abs(fract(.25+atan(x,z)/6.2831853)*2.-1.);float v=clamp(.49-asin(clamp(y,-1.,1.))*.98,0.002,.998);vec3 c=texture2D(photo,vec2(u,v)).rgb;gl_FragColor=vec4(mix(c,vec3(.44,.66,.83),smoothstep(.44,.93,y)),1.);}');
 const mesh=program('attribute vec3 pos;attribute vec3 color;varying vec3 c;uniform vec4 rot;uniform vec2 lens;uniform float eyeX;void main(){vec3 p=pos-vec3(eyeX,1.5,0.);float d=-p.z;float x=p.x*rot.y-d*rot.x;float z=p.x*rot.x+d*rot.y;float y=p.y*rot.w-z*rot.z;z=p.y*rot.z+z*rot.w;gl_Position=vec4(x/lens.x,y/lens.y,1.002*z-.1001,z);c=color;}', 'precision mediump float;varying vec3 c;void main(){gl_FragColor=vec4(c,1.);}');
 function buffer(arr){let b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,arr,gl.STATIC_DRAW);return b}
 const bg=buffer(new Float32Array([-1,-1,3,-1,-1,3])),objects=buffer(roomMesh);
 const tex=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,1,1,0,gl.RGB,gl.UNSIGNED_BYTE,new Uint8Array([158,192,214]));for(const k of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T])gl.texParameteri(gl.TEXTURE_2D,k,gl.CLAMP_TO_EDGE);for(const k of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,k,gl.LINEAR);
 const im=new Image();im.onload=()=>{if(disposed)return;gl.bindTexture(gl.TEXTURE_2D,tex);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,im);onReady()};im.src='assets/alpine.jpg';
 function locations(p){return {rot:gl.getUniformLocation(p,'rot'),lens:gl.getUniformLocation(p,'lens'),pos:gl.getAttribLocation(p,'pos')}}
 const sk=locations(sky),ob=locations(mesh),col=gl.getAttribLocation(mesh,'color'),offset=gl.getUniformLocation(mesh,'eyeX');
 return {draw(w,h,f,y,p,eyeX){if(disposed)return;const scale=Math.min(1,850/Math.max(w,h));const W=Math.max(1,Math.round(w*scale)),H=Math.max(1,Math.round(h*scale));if(canvas.width!==W||canvas.height!==H){canvas.width=W;canvas.height=H}gl.viewport(0,0,W,H);gl.clear(gl.DEPTH_BUFFER_BIT);const rotate=[Math.sin(y),Math.cos(y),Math.sin(p),Math.cos(p)];
 function setup(prog,u,b,n,stride){gl.useProgram(prog);gl.uniform4fv(u.rot,rotate);gl.uniform2f(u.lens,w/(2*f),h/(2*f));gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.enableVertexAttribArray(u.pos);gl.vertexAttribPointer(u.pos,n,gl.FLOAT,false,stride,0)}
 gl.disable(gl.DEPTH_TEST);setup(sky,sk,bg,2,0);gl.drawArrays(gl.TRIANGLES,0,3);gl.enable(gl.DEPTH_TEST);setup(mesh,ob,objects,3,24);gl.uniform1f(offset,eyeX);gl.enableVertexAttribArray(col);gl.vertexAttribPointer(col,3,gl.FLOAT,false,24,12);gl.drawArrays(gl.TRIANGLES,0,roomMesh.length/6);gl.disableVertexAttribArray(col)
 },close(){disposed=true;im.onload=null;const ext=gl.getExtension('WEBGL_lose_context');if(ext)ext.loseContext()}}
}
