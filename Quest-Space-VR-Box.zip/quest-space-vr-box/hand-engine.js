'use strict';
class BackgroundTask {
 constructor(source,module=false){
  this.pending=new Map();this.serial=0;this.closed=false;
  this.url=URL.createObjectURL(new Blob([source],{type:'text/javascript'}));
  try{this.worker=new Worker(this.url,module?{type:'module'}:undefined);}catch(error){URL.revokeObjectURL(this.url);throw error;}
  this.worker.onmessage=event=>{const p=this.pending.get(event.data.id);if(!p)return;clearTimeout(p.timer);this.pending.delete(event.data.id);event.data.error?p.reject(new Error(event.data.error)):p.resolve(event.data);};
  this.worker.onerror=event=>{event.preventDefault();this.close(new Error('Background task failed'));};
 }
 call(data,transfer=[],timeout=10000){
  if(this.closed)return Promise.reject(new Error('Background task closed'));
  return new Promise((resolve,reject)=>{const id=++this.serial,timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('Background task timeout'));this.close();},timeout);this.pending.set(id,{resolve,reject,timer});try{this.worker.postMessage({...data,id},transfer);}catch(error){clearTimeout(timer);this.pending.delete(id);reject(error);}});
 }
 close(error=new Error('Background task closed')){if(this.closed)return;this.closed=true;this.worker.terminate();URL.revokeObjectURL(this.url);for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(error);}this.pending.clear();}
}
let localHandsScript=null;
function trimHandOutputs(engine){
 if(self.VERSION!=='0.4.1675469240')return false;
 const listeners=engine.h?.h?.listeners;if(!Array.isArray(listeners))return false;
 let changed=false;for(const listener of listeners){
  if(!Array.isArray(listener.wants)||!listener.wants.includes('multi_hand_landmarks')||!listener.wants.includes('multi_handedness'))continue;
  const unused=new Set(['image_transformed','multi_hand_world_landmarks']);
  // Keep the image stream as a frame-completion heartbeat, including empty detections.
  listener.wants=listener.wants.filter(name=>name!=='multi_hand_world_landmarks');
  for(const [key,value] of Object.entries(listener.outs||{}))if(unused.has(typeof value==='string'?value:value.stream))delete listener.outs[key];
  changed=true;
 }return changed;
}
// The bundled graph runs off the UI thread; landmarks alone return to the scene.
function localHandsWorkerMain(trimOutputs){
 let engine,latest={landmarks:[]};
 self.onmessage=async event=>{const m=event.data;try{
  if(m.op==='init'){
   if(typeof OffscreenCanvas!=='function')throw Error('OffscreenCanvas unavailable');
   self.createMediapipeSolutionsPackedAssets={locateFile:file=>m.base+file};
   importScripts(m.base+'hands.js');
   engine=new self.Hands({locateFile:file=>m.base+file});const trimmed=trimOutputs(engine);
   // CPU inference leaves the graphics queue available for camera and VR composition.
   engine.setOptions({useCpuInference:true,selfieMode:false,maxNumHands:1,modelComplexity:0,minDetectionConfidence:.5,minTrackingConfidence:.5});
   engine.onResults(result=>{latest={landmarks:result.multiHandLandmarks||[],handedness:(result.multiHandedness||[]).map(v=>[{categoryName:v.label,score:v.score}])};result.image?.close?.();});
   await engine.initialize();self.postMessage({id:m.id,ready:true,trimmed});return;
  }
  if(m.op==='infer'){
   const begin=performance.now();try{await engine.send({image:m.image});}finally{m.image.close();}
   self.postMessage({id:m.id,result:latest,spent:performance.now()-begin});
  }
 }catch(error){m.image?.close?.();self.postMessage({id:m.id,error:error.message||'Local hand inference failed'});}};
}
function handInputSize(source){const w=source.videoWidth||source.width||640,h=source.videoHeight||source.height||480,scale=Math.min(1,352/Math.max(w,h));return {width:Math.max(1,Math.round(w*scale)),height:Math.max(1,Math.round(h*scale))};}
async function createLocalHandsBackground(base){
 if(typeof Worker!=='function'||typeof OffscreenCanvas!=='function'||typeof createImageBitmap!=='function')return null;
 let task;try{
  task=new BackgroundTask('('+localHandsWorkerMain.toString()+')('+trimHandOutputs.toString()+')');
  const ready=await task.call({op:'init',base},[],30000);URL.revokeObjectURL(task.url);
  return {background:true,isolated:true,bundled:true,compatible:false,trimmedOutputs:ready.trimmed,task,async infer(source){
   const begin=performance.now(),size=handInputSize(source),image=await createImageBitmap(source,{resizeWidth:size.width,resizeHeight:size.height,resizeQuality:'low'});
   try{const message=await task.call({op:'infer',image},[image]);return {...message,modelSpent:message.spent,spent:performance.now()-begin};}catch(error){image.close();throw error;}
  },close(){task.close();}};
 }catch(error){task?.close();console.info('Mãos: execução separada indisponível.',error.message);return null;}
}
async function loadLocalHandsEngine(isolate=true){
 const base=new URL('assets/hands/',location.href).href;
 if(isolate){const isolated=await createLocalHandsBackground(base);if(isolated)return isolated;}
 // Compatibility path for older WebViews; keep the exact same normalized landmarks.
 if(!self.Hands){if(!localHandsScript)localHandsScript=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=base+'hands.js';script.onload=resolve;script.onerror=()=>{localHandsScript=null;reject(new Error('Não foi possível abrir o modelo local de mãos'));};document.head.appendChild(script);});await localHandsScript;}
 const engine=new self.Hands({locateFile:file=>base+file});const trimmed=trimHandOutputs(engine);let latest={landmarks:[]};
 engine.setOptions({selfieMode:false,maxNumHands:1,modelComplexity:0,minDetectionConfidence:.5,minTrackingConfidence:.5});
 engine.onResults(result=>{latest={landmarks:result.multiHandLandmarks||[],handedness:(result.multiHandedness||[]).map(v=>[{categoryName:v.label,score:v.score}])};if(typeof ImageBitmap!=='undefined'&&result.image instanceof ImageBitmap)result.image.close();});
 await engine.initialize();const input=document.createElement('canvas'),ctx=input.getContext('2d',{alpha:false});return {background:true,bundled:true,compatible:true,trimmedOutputs:trimmed,async infer(source){const begin=performance.now(),size=handInputSize(source);if(input.width!==size.width||input.height!==size.height){input.width=size.width;input.height=size.height;}ctx.drawImage(source,0,0,size.width,size.height);await engine.send({image:input});return {result:latest,spent:performance.now()-begin};},close(){void engine.close();}};
}
