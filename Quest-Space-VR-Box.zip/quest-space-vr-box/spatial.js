'use strict';
const el=id=>document.getElementById(id);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const stage=el('stage');
const portrait=matchMedia('(orientation: portrait)');
let views=[],dual=false,stream=null,gyro=false,actual=null,origin=null,az=0,alt=0,grab=null,dirty=true;
let screenName='home',round=null,gameTimers=[],noticeTimer=0,sessionId=0,starting=false;
let engine=null,engineJob=null,handsOn=false,pending=false,nextSample=0,pinched=false,lastHand=0,lastVideo=-1;
let handVersion=0, handPose=null, handDisplay=null, handDrawAt=0, handPaint=null, handInterval=90, pinchReady=false, gazeReady=false;
let gazeKey=null,gazeSince=0,gazeFired=false,lastAim=0,frames=0,sampleTime=0,fps=60,minimum=Infinity;
const icons={
neon:'<circle cx="16" cy="16" r="12"/><circle cx="16" cy="16" r="6"/><path d="M16 1v5m0 20v5M1 16h5m20 0h5"/>',
memory:'<rect x="3" y="3" width="10" height="10" rx="2"/><rect x="19" y="3" width="10" height="10" rx="2"/><rect x="3" y="19" width="10" height="10" rx="2"/><rect x="19" y="19" width="10" height="10" rx="2"/>'};
function tile(k,title,sub){return '<button class="tile '+k+'" data-cmd="'+k+'"><svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="1.7">'+icons[k]+'</svg><strong>'+title+'</strong><small>'+sub+'</small></button>'}
function notify(text){clearTimeout(noticeTimer);el('notice').textContent=text;el('notice').hidden=false;noticeTimer=setTimeout(()=>el('notice').hidden=true,5200)}
function record(k,score){try{const key='quest.space.'+k;const best=Math.max(+(localStorage.getItem(key)||0),score);localStorage.setItem(key,best);return best}catch(e){return score}}
function content(){
 if(screenName==='home')return navigatorHome();
 if(screenName==='explore')return '';
 if(screenName==='browser')return browserPanel();
 if(screenName==='place')return placePanel();
 if(screenName==='apps')return '<div class="eyebrow">Navigator</div><h1>Biblioteca</h1>'+appTiles()+'<button class="library" data-cmd="library">Abrir ambientes panorâmicos</button>';
 if(screenName==='tools')return '<div class="eyebrow">Navigator</div><h1>Controles rápidos</h1><div class="adjust">'+[['motion','Giroscópio'],['mr','Realidade mista'],['vr','VR Box'],['fullscreen','Tela cheia'],['reset','Centralizar'],['place','Posicionar painel']].map(v=>'<button class="smallbtn" data-cmd="'+v[0]+'">'+v[1]+'</button>').join('')+'</div>';
 const neon=screenName==='neon',title=neon?'Alvos Neon':'Memória Espacial';
 let body='<p class="sub">'+(neon?'Acerte o máximo de alvos em 30 segundos.':'Observe as luzes e repita a sequência na mesma ordem.')+'</p>';
 if(round&&round.done)body+='<div class="gamebar"><strong>'+round.result+'</strong><span class="tag">Recorde: '+round.best+'</span></div>';
 else if(round&&neon)body+='<div class="board"><button class="target" aria-label="Acertar alvo" data-cmd="hit"></button></div><div class="gamebar"><b class="score"></b><span class="time"></span></div>';
 else if(round)body+='<div class="padgrid">'+['1','2','3','4'].map((v,i)=>'<button class="pad" data-cmd="pad'+i+'">'+v+'</button>').join('')+'</div><div class="gamebar"><strong class="hint"></strong><span class="score tag"></span></div>';
 if(!round||round.done)body+='<div class="gamebar"><button class="smallbtn" data-cmd="play">'+(round?'Jogar novamente':'Começar')+'</button><button class="smallbtn" data-cmd="home">Menu</button></div>';
 return '<div class="eyebrow">Arcade espacial</div><h1>'+title+'</h1>'+body;
}
function panelUpdate(){const html=content();stage.classList.toggle('exploring',screenName==='explore');views.forEach(v=>{v.panel.innerHTML=html;const clock=v.panel.querySelector('.clock');if(clock)clock.textContent=new Date().toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})});dirty=true;el('back').hidden=screenName==='home';gazeReady=false;gazeKey=null;gazeFired=false;stage.style.setProperty('--dwell',0);stats()}
function build(){
 stage.classList.toggle('dual',dual);
 document.body.classList.toggle('vrbox',dual);
 while(views.length>(dual?2:1)){
  const v=views.pop();
  if(v.room)v.room.close();
  v.video.srcObject=null;
  v.eye.remove();
 }
 while(views.length<(dual?2:1)){
  const eye=document.createElement('section');
  eye.className='eye';
  eye.innerHTML='<canvas class="lounge" aria-hidden="true"></canvas><video muted autoplay playsinline></video><div class="anchor"><div class="panel"></div><button class="handle" data-cmd="place" aria-label="Mover painel" title="Arraste para mover"></button>'+navigatorDock()+'</div><div class="reticle" aria-hidden="true"></div><canvas class="skeleton" aria-hidden="true"></canvas>';
  stage.appendChild(eye);
  const video=eye.querySelector('video'),canvas=eye.querySelector('.skeleton');
  const view={eye,video,canvas,anchor:eye.querySelector('.anchor'),panel:eye.querySelector('.panel'),ctx:canvas.getContext('2d')};
  views.push(view);
  try{view.room=createLounge(eye.querySelector('.lounge'),()=>{view.drawn=null;dirty=true})}catch(e){console.warn('WebGL',e.message)}
  video.muted=true;
  video.hidden=!stream;
  if(stream){video.srcObject=stream;video.play().catch(()=>{})}
 }
 handGrab=null;
 handPaint=null;
 gazeReady=false;
 layout();
 panelUpdate();
}
function layout(){
 views.forEach(v=>{
  v.w=v.eye.clientWidth;v.h=v.eye.clientHeight;v.left=v.eye.offsetLeft;
  if(v.canvas.width!==v.w||v.canvas.height!==v.h){v.canvas.width=v.w;v.canvas.height=v.h}
 });
 handPaint=null;
 dirty=true;
}
function stats(){
 if(!round||round.done)return;
 views.forEach(v=>{const q=s=>v.panel.querySelector(s);if(screenName==='neon'){const t=q('.target');t.style.left=round.x+'%';t.style.top=round.y+'%';q('.score').textContent=round.score+(round.score===1?' acerto':' acertos');q('.time').textContent=Math.max(0,Math.ceil((round.end-performance.now())/1000))+' s'}
 else{q('.score').textContent='Rodada '+round.seq.length;q('.hint').textContent=round.listening?'Sua vez':'Observe';v.panel.querySelectorAll('.pad').forEach((n,i)=>{n.disabled=!round.listening;n.classList.toggle('lit',i===round.light)})}})
}
function later(f,ms){gameTimers.push(setTimeout(f,ms))}
function cancelGame(){gameTimers.forEach(clearTimeout);gameTimers=[];round=null}
function randomSpot(){round.x=14+Math.random()*72;round.y=26+Math.random()*48}
function memoryTurn(){gameTimers.forEach(clearTimeout);gameTimers=[];round.seq.push(Math.floor(Math.random()*4));round.at=0;round.listening=false;round.light=-1;stats();round.seq.forEach((v,i)=>{later(()=>{round.light=v;stats()},450+i*770);later(()=>{round.light=-1;stats()},900+i*770)});later(()=>{round.listening=true;stats()},480+round.seq.length*770)}
function finish(){if(!round||round.done)return;const n=screenName==='neon'?round.score:round.seq.length-1;round.done=true;round.best=record(screenName,n);round.result=n+(screenName==='neon'?' acertos':' sequências completas');panelUpdate()}
function cmd(k){
 if(k==='library'){location.href='ambientes.html';return}
 if(['home','apps','neon','memory','explore','place','browser','tools'].includes(k)){
  cancelGame();let rebuild=false;
  if(screenName==='browser'&&k!=='browser'&&restoreDual){dual=true;restoreDual=false;rebuild=true}
  if(k==='browser'&&dual){dual=false;restoreDual=true;rebuild=true;notify('Navegador em tela única. O modo VR Box volta ao fechar a janela.')}
  if(screenName==='explore'&&k!=='explore')panelCenter();screenName=k;
  if(rebuild){el('split').textContent=dual?'Tela única':'VR Box';build()}else panelUpdate();
  if(k==='explore'){if(stream){const keep=gyro;stop();if(keep){window.addEventListener('deviceorientation',orientation);gyro=true}}notify('Arraste para olhar ao redor. Toque em Menu para voltar.')}
  return
 }
 if(k==='example'){goWeb('https://example.org');return}
 if(k==='prev'||k==='nexturl'){urlIndex=clamp(urlIndex+(k==='prev'?-1:1),0,urlStack.length-1);panelUpdate();return}
 if(k==='reload'){panelUpdate();return}
 if(k==='motion'){startGyro(sessionId).then(ok=>notify(ok?'Giroscópio ativado.':'Sensor indisponível. Arraste a vista para olhar ao redor.'));return}
 if(k==='mr'||k==='vr'||k==='fullscreen'){el({mr:'start',vr:'split',fullscreen:'full'}[k]).click();return}
 if(k==='reset'){panelCenter();return}
 if(['left','right','up','down','smaller','larger'].includes(k)){
  if(k==='left'||k==='right')panelYaw+=(k==='left'?-1:1)*.08;
  if(k==='up'||k==='down')panelPitch=clamp(panelPitch+(k==='up'?1:-1)*.07,-1.28,1.28);
  if(k==='smaller'||k==='larger')panelZoom=clamp(panelZoom+(k==='smaller'?-.1:.1),.55,1.35);
  dirty=true;return
 }
 if(k==='play'){cancelGame();if(screenName==='neon'){round={end:performance.now()+30000,score:0};randomSpot();later(finish,30000);panelUpdate()}else{round={seq:[],listening:false,light:-1};panelUpdate();memoryTurn()}return}
 if(!round||round.done)return;
 if(k==='hit'&&screenName==='neon'){if(performance.now()>=round.end){finish();return}round.score++;randomSpot();stats()}
 if(k.startsWith('pad')&&round.listening){let i=+k.slice(3);if(i!==round.seq[round.at]){finish();return}round.at++;round.light=i;stats();if(round.at===round.seq.length){round.listening=false;later(memoryTurn,380)}else later(()=>{round.light=-1;stats()},180)}
}
function orientation(e){
 if(e.alpha==null||e.beta==null||e.gamma==null)return;
 const r=Math.PI/180,a=e.alpha*r,b=e.beta*r,g=e.gamma*r;
 const x=-Math.cos(a)*Math.sin(g)-Math.sin(a)*Math.sin(b)*Math.cos(g),y=-Math.sin(a)*Math.sin(g)+Math.cos(a)*Math.sin(b)*Math.cos(g),z=-Math.cos(b)*Math.cos(g);
 actual=[Math.atan2(x,y)/r,Math.asin(clamp(z,-1,1))/r];if(!origin)origin=actual;dirty=true
}
async function startGyro(id){try{const D=window.DeviceOrientationEvent;if(!D)return false;if(D.requestPermission&&await D.requestPermission()!=='granted')return false;if(id!==sessionId)return false;window.addEventListener('deviceorientation',orientation);gyro=true;return true}catch(e){return false}}
function center(){az=alt=0;origin=actual;dirty=true}
function position(){
 const [yaw,pitch]=viewportAngles(),dy=panelYaw-yaw,cp=Math.cos(panelPitch),py=Math.sin(panelPitch),forward=cp*Math.cos(dy);
 const x=cp*Math.sin(dy),y=py*Math.cos(pitch)-forward*Math.sin(pitch),z=py*Math.sin(pitch)+forward*Math.cos(pitch);
 views.forEach((v,i)=>{
  const f=Math.min(v.w*.86,v.h*1.12),eyeOffset=dual?(i ? .032 : -.032):0;
  if(v.room&&!stream&&(!v.drawn||v.drawn.w!==v.w||v.drawn.h!==v.h||Math.abs(v.drawn.yaw-yaw)+Math.abs(v.drawn.pitch-pitch)>.0008)){
   v.room.draw(v.w,v.h,f,yaw,pitch,eyeOffset);v.drawn={w:v.w,h:v.h,yaw,pitch}
  }
  const explore=screenName==='explore';v.anchor.style.visibility=!explore&&z<.2?'hidden':'visible';
  if(explore){v.anchor.style.transform='translate(-50%,-50%)';return}
  if(z>=.2)v.anchor.style.transform='translate(-50%,-50%) translate3d('+((x-eyeOffset/2.4)*f/z).toFixed(1)+'px,'+(-y*f/z).toFixed(1)+'px,0) perspective('+f+'px) rotateY('+(-dy)+'rad) scale('+panelZoom+')'
 });dirty=false
}
function clearHand(){handGrab=null;lastHand=0;pinched=false;pinchReady=false;handPose=handDisplay=null;handDrawAt=0;handPaint=null;views.forEach(v=>v.ctx.clearRect(0,0,v.w,v.h))}
async function enableHands(){if(!stream||handsOn)return;handsOn=true;el('hand').textContent='Carregando mão';try{
 if(!engine){if(!engineJob)engineJob=loadLocalHandsEngine().finally(()=>engineJob=null);engine=await engineJob}if(!handsOn||!stream)return;
 el('hand').textContent='Mão ativa';notify('Mostre a mão inteira. Una polegar e indicador para selecionar.')
 }catch(e){handsOn=false;el('hand').textContent='Ativar mão';notify('Falha ao iniciar o modelo de mãos. Toque em Mão para tentar novamente.')}}
function disableHands(){handVersion++;lastVideo=-1;handsOn=false;clearHand();el('hand').textContent='Ativar mão'}
function stop(){sessionId++;starting=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;disableHands();window.removeEventListener('deviceorientation',orientation);gyro=false;origin=actual=null;center();el('start').disabled=false;el('start').textContent='Ativar realidade mista';views.forEach(v=>{v.video.srcObject=null;v.video.hidden=true})}
async function start(){
 if(stream){stop();notify('Câmera e sensores desligados.');return}if(starting)return;starting=true;const id=++sessionId;el('start').disabled=true;const gp=startGyro(id);
 try{if(!navigator.mediaDevices)throw Error();const cam=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:640},height:{ideal:480},frameRate:{ideal:30,max:30}}});if(id!==sessionId){cam.getTracks().forEach(t=>t.stop());return}stream=cam;cam.getVideoTracks()[0].addEventListener('ended',()=>{if(stream===cam){stop();notify('A câmera foi interrompida. Toque em Ativar realidade mista para retomar.')}});views.forEach(v=>{v.video.srcObject=stream;v.video.hidden=false;v.video.play().catch(()=>{})});el('start').textContent='Desligar MR';minimum=Infinity;sampleTime=0;enableHands();
 }catch(e){if(id===sessionId)notify('Câmera indisponível. Abra por HTTPS e permita a câmera nas opções do Safari.')}
 finally{if(id===sessionId){starting=false;el('start').disabled=false}}
 if(!(await gp)&&stream&&id===sessionId)notify('Giroscópio indisponível. Arraste para mover o painel.')
}
const bones=[[0,1,2,3,4],[0,5,6,7,8],[5,9,10,11,12],[9,13,14,15,16],[13,17,18,19,20],[0,17]];
function handResult(points){
 if(!points||points.length!==21||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))return;
 const now=performance.now(), elapsed=lastHand?now-lastHand:0;
 if(elapsed)handInterval=handInterval*.8+clamp(elapsed,16,400)*.2;
 lastHand=now;
 const video=views[0].video, aspect=(video.videoWidth||640)/(video.videoHeight||480);
 const distance=(a,b)=>Math.hypot((a.x-b.x)*aspect,a.y-b.y);
 const palm=Math.max(distance(points[5],points[17]),distance(points[0],points[9])*.8,.012);
 const ratio=distance(points[4],points[8])/palm;
 // Require an open hand before accepting a pinch, including after reacquisition.
 if(ratio>.48){pinchReady=true;pinched=false;handGrab=null}
 const press=pinchReady&&!pinched&&ratio<.31;
 if(press)pinched=true;
 handPose=points;
 if(!handDisplay)handDisplay=points.map(p=>({x:p.x,y:p.y}));
 if(press){
  const v=views[0],p=handPoint(v,points[8]), x=v.left+p[0],y=p[1];
  const hit=targetAt(x,y);
  if(hit&&hit.classList.contains('handle'))handGrab=beginMove(x,y,v);
  else if(hit)cmd(hit.dataset.cmd);
 }
}
function handPoint(view,p){
 const source=views[0].video,vw=source.videoWidth||640,vh=source.videoHeight||480;
 const scale=Math.max(view.w/vw,view.h/vh),w=vw*scale,h=vh*scale;
 return [(view.w-w)/2+p.x*w,(view.h-h)/2+p.y*h];
}
function drawHand(now){
 if(!handPose)return;
 if(now-lastHand>clamp(handInterval*2.4,170,560)){clearHand();return}
 const dt=handDrawAt?clamp(now-handDrawAt,1,50):16;
 handDrawAt=now;
 let motion=0;
 for(let i=0;i<21;i++){
  const goal=handPose[i], point=handDisplay[i];
  const dx=goal.x-point.x,dy=goal.y-point.y;
  // Small changes are steadied. A fast gesture gets a much shorter filter time.
  const distance=Math.hypot(dx,dy);
  motion=Math.max(motion,distance);
  const rate=1-Math.exp(-dt/clamp(54-distance*930,9,54));
  point.x+=dx*rate;point.y+=dy*rate;
 }
 const fade=1-clamp((now-lastHand-handInterval*1.4)/120,0,.7);
 const paintState=pinched+' '+fade.toFixed(2);
 if(!handGrab&&motion<.0006&&handPaint===paintState)return;
 handPaint=paintState;
 views.forEach((v,i)=>{
  const xy=handDisplay.map(p=>handPoint(v,p)),g=v.ctx;
  g.clearRect(0,0,v.w,v.h);g.globalAlpha=fade;g.lineCap='round';
  g.strokeStyle='#99ffdb';g.lineWidth=dual?1.5:2;
  g.beginPath();bones.forEach(line=>line.forEach((j,n)=>n?g.lineTo(...xy[j]):g.moveTo(...xy[j])));g.stroke();
  g.fillStyle=pinched?'#ffdc8b':'#fff';g.beginPath();g.arc(...xy[8],dual?4:6,0,Math.PI*2);g.fill();
  g.globalAlpha=1;
  if(i===0&&pinched&&handGrab)movePanel(v.left+xy[8][0],xy[8][1],handGrab);
 });
}
async function infer(now){
 const video=views[0].video;
 if(!handsOn||!engine||pending||now<nextSample||video.readyState<2||lastVideo===video.currentTime)return;
 const version=handVersion,active=engine;
 lastVideo=video.currentTime;pending=true;
 try{
  const result=await active.infer(video);
  if(version===handVersion&&handsOn&&(!dual||!portrait.matches))handResult(result.result.landmarks[0]);
  // Leave room for presentation when the compatibility engine shares the UI thread.
  const pause=active.isolated
   ? (fps<48?105:24)
   : clamp(result.spent*(fps<48?3:1.35),22,480);
  nextSample=performance.now()+pause;
 }catch(error){
  if(version!==handVersion||!handsOn)return;
  if(active.isolated){
   active.close();engine=null;
   engineJob=loadLocalHandsEngine(false);
   try{engine=await engineJob}catch(e){if(version===handVersion)disableHands()}
   finally{engineJob=null}
  }else{
   active.close();engine=null;disableHands();
   notify('Detecção interrompida. Toque em Mão para retomar.');
  }
 }finally{pending=false}
}
function targetAt(x,y){const node=document.elementFromPoint(x,y);return node&&node.closest('[data-cmd]:not(:disabled)')}
function gaze(now){
 if(!dual||portrait.matches||now-lastAim<45)return;
 lastAim=now;
 const v=views[0];
 const target=lastHand?null:targetAt(v.left+v.w/2,v.h/2);
 if(!gazeReady){
  if(!target||gazeKey&&target!==gazeKey)gazeReady=true;
  gazeKey=target;gazeSince=now;
  return;
 }
 if(target!==gazeKey){gazeKey=target;gazeSince=now;gazeFired=false}
 const progress=target&&!gazeFired?clamp((now-gazeSince)/1200,0,1):0;
 stage.style.setProperty('--dwell',progress);
 if(progress===1){gazeFired=true;cmd(target.dataset.cmd)}
}
function tick(now){
 if(!sampleTime){sampleTime=now;frames=0}else frames++;
 if(now-sampleTime>=1000){
  fps=1000*frames/(now-sampleTime);minimum=Math.min(minimum,fps);
  el('fps').textContent=Math.round(fps)+' FPS · mín '+Math.floor(minimum);
  sampleTime=now;frames=0;
  if(round&&!round.done&&screenName==='neon')stats();
 }
 if(dirty)position();
 if(handsOn){if(!dual||!portrait.matches)infer(now);drawHand(now)}
 gaze(now);
 requestAnimationFrame(tick);
}
let suppress=0;
stage.addEventListener('submit',e=>{if(e.target.classList.contains('address')){e.preventDefault();goWeb(e.target.querySelector('input').value)}});
stage.addEventListener('pointerdown',e=>{suppress=0;if(e.target.closest('input,form,iframe'))return;const h=e.target.closest('.handle'),v=views.find(v=>v.eye.contains(e.target));grab={id:e.pointerId,x:e.clientX,y:e.clientY,az,alt,moved:false,move:h&&beginMove(e.clientX,e.clientY,v)};if(h)h.setPointerCapture(e.pointerId)});
window.addEventListener('pointermove',e=>{if(!grab||e.pointerId!==grab.id)return;const dx=e.clientX-grab.x,dy=e.clientY-grab.y;if(Math.abs(dx)+Math.abs(dy)>6)grab.moved=true;if(grab.moved){if(grab.move){movePanel(e.clientX,e.clientY,grab.move);return}az=grab.az-dx*.13;alt=clamp(grab.alt+dy*.12,-65,65);dirty=true}});
function endDrag(){if(grab&&grab.moved)suppress=performance.now()+250;grab=null}
window.addEventListener('pointerup',endDrag);window.addEventListener('pointercancel',endDrag);
stage.addEventListener('click',e=>{const b=e.target.closest('[data-cmd]');if(b){e.preventDefault();if(performance.now()>=suppress)cmd(b.dataset.cmd)}});
el('start').onclick=start;el('center').onclick=()=>{center();panelCenter();notify('Painel centralizado.')};el('back').onclick=()=>cmd('home');
el('hand').onclick=()=>{if(!stream){start();return}if(handsOn)disableHands();else enableHands()};
el('split').onclick=()=>{if(screenName==='browser'){restoreDual=false;screenName='home'}dual=!dual;el('split').textContent=dual?'Tela única':'VR Box';build();center();panelCenter();if(dual){startGyro(sessionId);if(!portrait.matches)notify('Mire por 1,2 s para selecionar.')}};
el('full').onclick=async()=>{try{if(document.fullscreenElement||document.webkitFullscreenElement){await(document.exitFullscreen||document.webkitExitFullscreen).call(document);return}const root=document.documentElement,fn=root.requestFullscreen||root.webkitRequestFullscreen;if(fn){await fn.call(root);return}if(navigator.standalone){notify('O visor já está em tela cheia.');return}}catch(e){}el('fullHelp').hidden=false};
el('leaveVr').onclick=()=>el('split').click();
el('dismiss').onclick=()=>el('fullHelp').hidden=true;
window.addEventListener('resize',layout);window.addEventListener('orientationchange',()=>setTimeout(()=>{origin=null;actual=null;center();panelCenter();gazeReady=false;gazeKey=null;handVersion++;clearHand();layout()},300));
window.addEventListener('pagehide',stop);document.addEventListener('visibilitychange',()=>{if(document.hidden){if(stream||starting||gyro)stop();if(round&&!round.done){cancelGame();panelUpdate()}}sampleTime=0});
build();requestAnimationFrame(tick)
